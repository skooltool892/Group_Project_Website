let words = [
    {
        word: "Carbon Dioxide",
        hint: "A Naturally occuring gas, a by-product of fossil fuels"
    },
    {
        word: "Climate",
        hint: "the Average weather"
    },
    {
        word: "Fossil Fuel",
        hint: "a potent energy source, but harmful fumes are emitted"
    },
    {
        word: "Deforestation",
        hint: "Conversion of Forest into land fit for industrial use."
    },
    {
        word: "Ecosystem",
        hint: "Any natural unit including living and non-living participants"
    },
    {
        word: "Emissions",
        hint: "The release of a substance into the atmosphere"
    },
    {
        word: "Mitigation",
        hint: "Human intervention to reduce human impact"
    },
    {
        word: "Ozone",
        hint: "Acts as a blanket protecting earth from harmful UV rays"
    },
    {
        word: "Radiation",
        hint: "Electromagnetic waves that release energy when absorbed"
    },
    {
        word: "Recycling",
        hint: "the act of reducing waste via reusing disposables"
    },
]